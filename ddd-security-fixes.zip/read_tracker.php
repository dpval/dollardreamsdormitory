<?php
require_once "auth.php";
require_admin_api();
include "db.php";


header('Content-Type: application/json');

$result = $conn->query("SELECT * FROM bookings");

if (!$result) {
    echo json_encode(["error" => $conn->error]);
    exit;
}

$data = [];

while ($row = $result->fetch_assoc()) {
    $data[] = $row;
}

echo json_encode($data);
?>