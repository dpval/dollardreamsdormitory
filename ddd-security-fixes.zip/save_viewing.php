<?php
include "db.php";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $name = trim($_POST['name'] ?? '');
    $mobile = trim($_POST['mobile'] ?? '');
    $schedule = trim($_POST['schedule'] ?? '');

    if (empty($name) || empty($mobile) || empty($schedule)) {
        exit("Missing fields");
    }

    $stmt = $conn->prepare("
        INSERT INTO viewing_requests (name, mobile, schedule, status, created_at)
        VALUES (?, ?, ?, 'Pending', NOW())
    ");

    if (!$stmt) {
        exit("Prepare failed: " . $conn->error);
    }

    $stmt->bind_param("sss", $name, $mobile, $schedule);

    if ($stmt->execute()) {

        // EMAIL NOTIFICATION (Resend, settings in config.php)
        send_notification_email('New Customer Viewing Request Received', "
                <h2>New Viewing Request</h2>
                <p>A customer has booked a schedule viewing request on the website.</p>
                <hr style='border: 1px solid #eee;'>
                <p><strong>Customer Name:</strong> " . htmlspecialchars($name) . "</p>
                <p><strong>Mobile Number:</strong> " . htmlspecialchars($mobile) . "</p>
                <p><strong>Requested Schedule Slot:</strong> " . htmlspecialchars($schedule) . "</p>
                <p><strong>Status:</strong> Pending</p>
            ");

        // ONLY ONE SUCCESS ECHO HERE
        echo "success";

    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>