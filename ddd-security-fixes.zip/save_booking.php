<?php
include "db.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $unit_id = intval($_POST['unit_id'] ?? 0);
    $unit_name = $_POST['unit'] ?? '';
    $room_type = $_POST['book_type'] ?? '';
    $description = $_POST['description'] ?? '';

    $name = $_POST['name'] ?? '';
    $mobile = $_POST['mobile'] ?? '';
    $email = $_POST['email'] ?? '';

    $price = floatval($_POST['price'] ?? 0);
    $reservation_fee = floatval($_POST['reservation_fee'] ?? 500);

    $move_in = $_POST['move_in'] ?? '';
    $move_out = $_POST['move_out'] ?? '';

    $payment = 0;
    $status = "PENDING";

    // TERM CALCULATION
    $term = 1;
    if ($move_in && $move_out) {
        $d1 = new DateTime($move_in);
        $d2 = new DateTime($move_out);
        $term = $d1->diff($d2)->days + 1;
    }

    $total = $price * $term;
    $balance = $total;

    // FILE UPLOAD HANDLING
    // Guest IDs and payment proofs are private: they go in private_uploads/,
    // which the .htaccess there blocks from being opened in a browser.
    $uploadDir = "private_uploads/";
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }

    // Only real images or PDFs, max 5MB. The file's actual contents are checked,
    // not just its name, and it's saved under a random name.
    // Both files are checked first, so a rejected booking leaves nothing behind.
    function check_private_upload($field, $label) {
        if (empty($_FILES[$field]['name']) || $_FILES[$field]['error'] !== UPLOAD_ERR_OK) {
            return null;
        }
        $allowed = [
            'image/jpeg' => 'jpg',
            'image/png'  => 'png',
            'image/webp' => 'webp',
            'application/pdf' => 'pdf',
        ];
        if ($_FILES[$field]['size'] > 5 * 1024 * 1024) {
            exit("$label must be under 5MB.");
        }
        $finfo = new finfo(FILEINFO_MIME_TYPE);
        $mime = $finfo->file($_FILES[$field]['tmp_name']);
        if (!isset($allowed[$mime])) {
            exit("$label must be a JPG, PNG, WEBP or PDF file.");
        }
        return $allowed[$mime];
    }

    function save_private_upload($field, $ext, $uploadDir) {
        if ($ext === null) {
            return "";
        }
        $path = $uploadDir . date('Ymd_His') . "_" . $field . "_" . bin2hex(random_bytes(8)) . "." . $ext;
        if (!move_uploaded_file($_FILES[$field]['tmp_name'], $path)) {
            exit("Could not save your file. Please try again.");
        }
        return $path;
    }

    $idExt  = check_private_upload('id_upload', 'Government ID');
    $payExt = check_private_upload('payment_proof', 'Payment proof');

    // 1. Government ID Upload
    $id_upload = save_private_upload('id_upload', $idExt, $uploadDir);

    // 2. GCash Payment Proof Upload
    $payment_proof = save_private_upload('payment_proof', $payExt, $uploadDir);

    // PREPARE DATABASE INSERT STATEMENT
    $stmt = $conn->prepare("
        INSERT INTO bookings (
            unit_id, unit_name, room_type, description,
            name, mobile, email,
            id_upload,
            move_in, move_out,
            term, reservation_fee,
            price, payment, total, balance,
            status, created_at
        )
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,NOW())
    ");

    $stmt->bind_param(
        "isssssssssiddidds",
        $unit_id,
        $unit_name,
        $room_type,
        $description,
        $name,
        $mobile,
        $email,
        $id_upload,
        $move_in,
        $move_out,
        $term,
        $reservation_fee,
        $price,
        $payment,
        $total,
        $balance,
        $status
    );

    if ($stmt->execute()) {

        // ==========================================
        // EMAIL NOTIFICATION (Resend, settings in config.php)
        // ==========================================
        $attachments = [];

        if (!empty($id_upload) && file_exists($id_upload)) {
            $attachments[] = [
                'filename' => basename($id_upload),
                'content'  => base64_encode(file_get_contents($id_upload)),
            ];
        }

        if (!empty($payment_proof) && file_exists($payment_proof)) {
            $attachments[] = [
                'filename' => basename($payment_proof),
                'content'  => base64_encode(file_get_contents($payment_proof)),
            ];
        }

        $html = "
                <h2>New Room Reservation Details</h2>
                <p><strong>Full Name:</strong> " . htmlspecialchars($name) . "</p>
                <p><strong>Mobile:</strong> " . htmlspecialchars($mobile) . "</p>
                <p><strong>Email:</strong> " . htmlspecialchars($email) . "</p>
                <p><strong>Unit Name:</strong> " . htmlspecialchars($unit_name) . "</p>
                <p><strong>Room Type:</strong> " . htmlspecialchars($room_type) . "</p>
                <p><strong>Reservation Fee:</strong> ₱" . number_format($reservation_fee, 2) . "</p>
                <p><strong>Move-In Date:</strong> " . htmlspecialchars($move_in) . "</p>
                <p><strong>Move-Out Date:</strong> " . htmlspecialchars($move_out) . "</p>
                <p><strong>Total Term:</strong> {$term} day(s)</p>
                <p><strong>Description:</strong> " . htmlspecialchars($description) . "</p>
                <br>
                <p><em>Government ID and Payment Proof are attached to this email.</em></p>
            ";

        // The booking is already saved, so the guest sees success even if the
        // email fails; failures are written to the server error log.
        send_notification_email('New Booking & Reservation Request Received', $html, $attachments);
        echo "success";

    } else {
        error_log('save_booking: ' . $stmt->error);
        echo "Sorry, your booking could not be saved. Please try again.";
    }

    $stmt->close();
}
?>