<?php
/*
 * Include at the very top of any admin-only script.
 *   require_once "auth.php"; require_admin_api();   // for AJAX/POST handlers
 *   require_once "auth.php"; require_admin_page();  // for pages
 */
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function require_admin_page() {
    if (empty($_SESSION['admin'])) {
        header("Location: signin.php");
        exit();
    }
}

function require_admin_api() {
    if (empty($_SESSION['admin'])) {
        http_response_code(403);
        exit("unauthorized");
    }
}
?>
