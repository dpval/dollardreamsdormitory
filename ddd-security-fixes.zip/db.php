<?php

$configFile = __DIR__ . "/config.php";
if (!file_exists($configFile)) {
    http_response_code(500);
    die("Missing config.php - copy config.example.php to config.php and fill it in.");
}
$config = require $configFile;

mysqli_report(MYSQLI_REPORT_OFF);
$conn = new mysqli(
    $config['db_host'],
    $config['db_user'],
    $config['db_pass'],
    $config['db_name']
);

if ($conn->connect_error) {
    error_log("DB connection failed: " . $conn->connect_error);
    http_response_code(500);
    die("Database connection failed.");
}

/* Hide PHP error details from visitors (they're still written to the error log). */
ini_set('display_errors', 0);

/* Sends a notification email through Resend. Returns [httpCode, responseBody]. */
function send_notification_email($subject, $html, $attachments = []) {
    global $config;

    $payload = [
        'from'    => $config['mail_from'],
        'to'      => $config['notify_emails'],
        'subject' => $subject,
        'html'    => $html,
    ];
    if (!empty($attachments)) {
        $payload['attachments'] = $attachments;
    }

    $ch = curl_init('https://api.resend.com/emails');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Authorization: Bearer ' . $config['resend_api_key'],
        'Content-Type: application/json'
    ]);

    $response = curl_exec($ch);
    if (curl_errno($ch)) {
        error_log('Resend cURL Error: ' . curl_error($ch));
    }
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpCode >= 400) {
        error_log('Resend error ' . $httpCode . ': ' . $response);
    }
    return [$httpCode, $response];
}

?>
